package com.tlHomeWork.zookeeper.znode;

import org.apache.zookeeper.KeeperException;

public class Test {
   public static void main(String[] args) throws KeeperException, InterruptedException {
      ZookeeperCrud zookeeperCrud=new ZookeeperCrud();
      zookeeperCrud.createPersistent("/liuzx","2018-11-18");
     // zookeeperCrud.createPersistentSequential("/liuzx01-s","2018-11-18");
      // zookeeperCrud.createPersistentSequential("/liuzx02-s","2018-11-18");
      if(null!=zookeeperCrud.exists("/liuzx"))
      zookeeperCrud.createEphemeral("/liuzx-e","abc");
      //zookeeperCrud.createEphemeralSequential ("/liuzx01-e-s","abc");
     // zookeeperCrud.createEphemeralSequential("/liuzx01-e-s","abc");
      zookeeperCrud.setData("/liuzx","2018-11-18 15:30:00");
      zookeeperCrud.getData("/liuzx");
      zookeeperCrud.delete("/liuzx");

      ZookeeperCrud zookeeperCrud01=new ZookeeperCrud();
      zookeeperCrud01.getData("/liuzx01");
   }
}
