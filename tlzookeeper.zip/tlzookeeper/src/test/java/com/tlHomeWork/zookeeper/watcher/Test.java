package com.tlHomeWork.zookeeper.watcher;

import org.apache.zookeeper.KeeperException;

public class Test {
   public static void main(String[] args) throws KeeperException, InterruptedException {
      ZookeeperWatcher zookeeperCrud=new ZookeeperWatcher();
      zookeeperCrud.createEphemeral("/liuzx","abc");

     zookeeperCrud.setData("/liuzx","aaa");
      System.out.println(new String(zookeeperCrud.getData("/liuzx",true)));
     zookeeperCrud.delete("/liuzx");
      //Thread.sleep(Long.MAX_VALUE);
   }
}
