package com.tlHomeWork.zookeeper.acl;

import org.apache.zookeeper.KeeperException;

public class ZookeeperAclTest {

   public static void main(String[] args) throws KeeperException, InterruptedException {
    /***没有权限**/
      ZookeeperAcl zookeeperAcl = new ZookeeperAcl();
     /* zookeeperAcl.createPersistentAcl("/liuzx","2018-11-18");
      zookeeperAcl.delete("/liuzx");*/

      /***这个是权限**/
      ZookeeperAcl zookeeperAcl2 = new ZookeeperAcl(true);
      ZookeeperAcl zookeeperAcl3 = new ZookeeperAcl(true);
      zookeeperAcl2.createPersistentAcl("/liuzxAcl","2018-11-18 16:00:00");
      zookeeperAcl2.getData("/liuzxAcl");
      Thread.sleep(5000);
      System.out.print("会话3获取会话2权限节点/liuzxAcl");
      zookeeperAcl3.getData("/liuzxAcl");
      System.out.print("会话1删除会话2权限节点/liuzxAcl");
      zookeeperAcl.delete("/liuzxAcl");




   }

}
